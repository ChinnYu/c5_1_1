import sqlalchemy as sa
import os

PEnv = os.environ.get('PYTHON_ENVIRONMENT')


class Config:
    DEBUG = True
    # DRIVER = "ODBC Driver 17 for SQL Server"
    connection_uri = ""
    if PEnv == "dev":
        connection_uri = sa.engine.url.URL(
            "mssql+pyodbc",
            username="sa",
            password="itsdk@forever",
            host="sdk-mssql",
            database="sdk_jenkins",
            query={
                "driver": "ODBC Driver 17 for SQL Server",
                # "ApplicationIntent": "ReadOnly",
            },
        )
    elif PEnv == "prod":
        connection_uri = sa.engine.url.URL(
            "mssql+pyodbc",
            username="sa",
            password="itsdk@forever",
            host="itsdkdev3",
            database="sdk_jenkins",
            query={
                "driver": "ODBC Driver 17 for SQL Server",
                # "ApplicationIntent": "ReadOnly",
            },
        )

    # print(connection_uri)
    # mysql+pymysql://user:password@hostip:port/databasename
    # SQLALCHEMY_DATABASE_URI = 'mssql+pyodbc://sa:itsdk@forever@itsdkdev3:1433/sdk_jenkins?driver=ODBC+Driver+17+for+SQL+Server&Encrypt=False&TrustServerCertificate=False&ApplicationIntent=ReadWrite&MultiSubnetFailover=False'
    SQLALCHEMY_DATABASE_URI = connection_uri
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ECHO = True


class DevelopmentConfig(Config):
    ENV = 'development'


class ProductionConfig(Config):
    ENV = 'production'
    DDEBUG = False
