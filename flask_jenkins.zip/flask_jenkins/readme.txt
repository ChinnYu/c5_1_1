python .\app.py runserver -h localhost -p 8080 -d
python .\app.py db migrate

flask run
flask db init
flask db migrate
flask db upgrade
