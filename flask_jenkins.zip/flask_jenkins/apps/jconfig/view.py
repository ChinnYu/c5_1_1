import hashlib
import json
from flask import Blueprint, render_template, request, redirect, url_for, jsonify
from sqlalchemy import or_, and_, not_

from apps.jconfig.models import JConfig
from exts import db

jconfig_bp = Blueprint('jconfig', __name__)

@jconfig_bp.route('/')
def getall():
    return jsonify({"where": "jc"})

# 注册
@jconfig_bp.route('/set', methods=['POST'])
def setConfig():
    if request.method == 'POST':
        pipe_name = request.form.get('pipe_name')
        parameter = request.form.get('parameter')
        token = request.form.get('token')
        # host_linux = request.form.get('host_linux')
        if pipe_name != "":
            pipe_config = JConfig.query.filter(JConfig.pipe_name.__eq__(pipe_name)).all()
            if not pipe_config:
                jconfig = JConfig()
                jconfig.pipe_name = pipe_name
                jconfig.token = token
                if parameter:
                    jconfig.parameter = parameter
                else:
                    return jsonify({"error": "parameter null"})
                db.session.add(jconfig)
                db.session.commit()
                return jsonify({"status": "OK"})
            else:
                return jsonify({"error": "duplicate"})
        else:
            return jsonify({"status": "Error"})


# 用户中心
@jconfig_bp.route('/get')
def getConfig():
    # 查询数据库中的数据
    pipe_name = request.args.get('pipe_name')
    print(pipe_name)
    if pipe_name != "":
        pipe_config = JConfig.query.filter(JConfig.pipe_name.__eq__(pipe_name)).all()
        for idx, x in enumerate(pipe_config):
            print(idx, x.pipe_name)
        if pipe_config:
            print(type(pipe_config[0]))
            print(pipe_config[0].pipe_name)
            print(pipe_config[0].token)
            json_object = json.loads(pipe_config[0].parameter)
            return jsonify(json_object)
        else:
            return jsonify({"error": "no match"})
    else:
        return jsonify({"error": "no match"})

@jconfig_bp.route('/update', methods=['POST'])
def config_update():
    if request.method == 'POST':
        pipe_name = request.form.get('pipe_name')
        parameter = request.form.get('parameter')
        token = request.form.get('token')
        # 找用户
        if pipe_name:
            pipe_config = JConfig.query.filter(JConfig.pipe_name.__eq__(pipe_name)).all()
            if pipe_config[0].token == token:
                if parameter:
                    pipe_config[0].parameter = parameter
                else:
                    pipe_config[0].parameter = pipe_config[0].parameter
                db.session.commit()
                return jsonify({"status": "OK"})
            else:
                return jsonify({"status": "Error"})
        else:
            return jsonify({"status": "Error"})


'''
# 登录
@jconfig_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        # 关键  select * from user where username='xxxx';
        new_password = hashlib.sha256(password.encode('utf-8')).hexdigest()
        # 查询
        user_list = User.query.filter_by(username=username)

        for u in user_list:
            # 此时的u表示的就是用户对象
            if u.password == new_password:
                return '用户登录成功！'
        else:
            return render_template('user/login.html', msg='用户名或者密码有误！')

    return render_template('user/login.html')


# 检索
@jconfig_bp.route('/search')
def search():
    keyword = request.args.get('search')  # 用户名 | 手机号
    # 查询
    user_list = User.query.filter(or_(User.username.contains(keyword), User.phone.contains(keyword))).all()
    return render_template('user/center.html', users=user_list)


# 用户删除
@jconfig_bp.route('/delete', endpoint='delete')
def user_delete():
    # 获取用户id
    id = request.args.get('id')
    # 1. 逻辑删除 （更新）
    # # 获取该id的用户
    # user = User.query.get(id)
    # # 逻辑删除：
    # user.isdelete = True
    # # 提交
    # db.session.commit()
    # 2. 物理删除
    user = User.query.get(id)
    # 将对象放到缓存准备删除
    db.session.delete(user)
    # 提交删除
    db.session.commit()

    return redirect(url_for('user.user_center'))


# 用户信息更新
@jconfig_bp.route('/update', endpoint='update', methods=['GET', 'POST'])
def user_update():
    if request.method == 'POST':
        username = request.form.get('username')
        phone = request.form.get('phone')
        id = request.form.get('id')
        # 找用户
        user = User.query.get(id)
        # 改用户信息
        user.phone = phone
        user.username = username
        # 提交
        db.session.commit()
        return redirect(url_for('user.user_center'))

    else:
        id = request.args.get('id')
        user = User.query.get(id)
        return render_template('user/update.html', user=user)


@jconfig_bp.route('/test')
def test():
    username = request.args.get('username')  # zhangsan
    user = User.query.filter_by(username=username).first()
    print(user.username, user.rdatetime)

    user = User.query.filter_by(username=username).last()
    print(user.username, user.rdatetime)
    return 'test'


@jconfig_bp.route('/select')
def user_select():
    user = User.query.get(2)  # 根据主键查询用户使用get（主键值）返回值是一个用户对象
    # user1 = User.query.filter(User.username == 'wangwu').all()  # all(), first()
    # user_list = User.query.filter(User.username.like('z%')).all()  # select * from user where username like 'z%';
    # 舒肤佳沐浴露柠檬清新1000ml 果香清爽 无皂基 新老包装随机发货
    # user_list = User.query.filter(or_(User.username.like('z%'), User.username.contains('i'))).all()
    # select * from user where username like 'z%' or username like '%i%';
    # user_list = User.query.filter(and_(User.username.contains('i'), User.rdatetime.__gt__('2020-05-25 10:30:00'))).all()
    # user_list = User.query.filter(and_(User.username.contains('i'), User.rdatetime > '2020-05-25 10:30:00')).all()
    # user_list = User.query.filter(not_(User.username.contains('i'))).all()
    # user_list = User.query.filter(User.phone.in_(['15810106788','13801011299'])).all()
    # user_list = User.query.filter(User.username.contains('z')).order_by(-User.rdatetime).all()
    # # user_list = User.query.order_by(-User.id).all()

    # limit的使用 + offset
    # user_list = User.query.limit(2).all()
    user_list = User.query.offset(4).limit(2).all()
    return render_template('user/select.html', user=user, users=user_list)


@jconfig_bp.route('/test1')
def test1():
    return render_template('user/test.html')

'''


'''
______
______
  登录
  
提交过来： username + password

跟数据库中数据进行匹配
-----
----
-----
-----
-----

'''
