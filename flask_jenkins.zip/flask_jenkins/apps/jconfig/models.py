from datetime import datetime

from exts import db


class JConfig(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pipe_name = db.Column(db.String(150), nullable=False)
    token = db.Column(db.String(64), nullable=False)
    parameter = db.Column(db.String(2000))
    is_delete = db.Column(db.Boolean, default=False)
    r_datetime = db.Column(db.DateTime, default=datetime.now)

    def __str__(self):
        return str(self.parameter)
